

document.write("<script src='http://html5shim.googlecode.com/svn/trunk/html5.js'></script>");

document.createElement('header');
document.createElement('section');
document.createElement('article');
document.createElement('aside');
document.createElement('nav');
document.createElement('footer');

